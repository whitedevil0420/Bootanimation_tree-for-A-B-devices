this is a simple template of changing boot animation of your Android

simply extract this zip and replace your bootanimation.zip in system golder and now compress all folders .

don't touch other files

now it become a magisk module that is ready to flash with magisk or twrp

(recommended magisk )



backup your current boot animation zip if ny error goes
(i can tell there is no error you face)


for any query
dm me at teligram at @white_devil_0420
   https://t.me/white_devil_0420
